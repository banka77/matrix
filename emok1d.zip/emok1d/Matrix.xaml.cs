﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace emok1d
{
    /// <summary>
    /// Логика взаимодействия для DoubleArray.xaml
    /// </summary>
    public partial class Matrix : Window
    {
        public Matrix()
        {
            InitializeComponent();
        }

        private void btn1_Click(object sender, RoutedEventArgs e)
        {
            int rows = 0, columns = 0;

            if (int.TryParse(Rows.Text, out rows) && int.TryParse(Columns.Text, out columns))
            {
                var matrix = new ObservableCollection<ObservableCollection<int>>();

                Random rand = new Random();
                for (int i = 0; i < rows; i++)
                {
                    var row = new ObservableCollection<int>();
                    for (int j = 0; j < columns; j++)
                    {
                        row.Add(rand.Next(1, 101));
                    }
                    matrix.Add(row);
                }

                DtgDoubleArray.ItemsSource = matrix;

                DtgDoubleArray.Columns.Clear();
                for (int i = 0; i < columns; i++)
                {
                    DtgDoubleArray.Columns.Add(new DataGridTextColumn
                    {
                        Header = $"Столбец {i + 1}",
                        Binding = new System.Windows.Data.Binding($"[{i}]")
                    });
                }

                int maxElement = matrix[0][0];
                foreach (var row in matrix)
                {
                    foreach (var element in row)
                    {
                        if (element > maxElement)
                        {
                            maxElement = element;
                        }
                    }
                }

                Max.Text = "" + maxElement;
            }
            else
            {
                MessageBox.Show("Введите корректные размеры матрицы.");
            }
        }
    }
}