﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static System.Net.Mime.MediaTypeNames;

namespace emok1d
{
    /// <summary>
    /// Логика взаимодействия для WindowArray.xaml
    /// </summary>
    public partial class WindowArray : Window
    {
        int N = 27;
        double[] arrayNumber = new double[27];
        double[] arrayY = new double[27];

        public WindowArray()
        {
            InitializeComponent();
        }

        private void BtnMas_Click(object sender, RoutedEventArgs e)
        {
            massive1.Items.Clear();
            var rand = new Random();
            for (int i = 0; i < N; i++)
            {
                double number = Math.Round(rand.NextDouble() * 10 - 10, 3);
                arrayNumber[i] = number;
                massive1.Items.Add($"X[{i}] = {number:F3}");
            }
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            massive1.Items.Clear();
            massive2.Items.Clear();
        }

        private void BtnEditMas_Click(object sender, RoutedEventArgs e)
        {
            massive2.Items.Clear();

            for (int i = 0; i < N; i++)
            {
                double x_i = arrayNumber[i];
                double y_i = 6.85 * Math.Pow(x_i, 2) - 1.52;
                arrayY[i] = y_i;

                if (y_i < 0)
                {
                    double a = Math.Pow(x_i, 3) - 0.62;
                    massive2.Items.Add($"a[{i}] = {a:F3}");
                }
                else
                {
                    double b = 1 / Math.Pow(x_i, 2);
                    massive2.Items.Add($"b[{i}] = {b:F6}");
                }
            }
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Tab)
            {
                MessageBoxResult result = MessageBox.Show("Вы уверены, что хотите удалить массивы?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (result == MessageBoxResult.Yes)
                {
                    massive1.Items.Clear();
                    massive2.Items.Clear();
                }
                else
                {
                    MessageBox.Show("Вы отменили действие");
                }
            }
        }
    }
}