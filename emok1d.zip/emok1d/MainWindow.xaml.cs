﻿using Microsoft.Win32;
using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Documents.Serialization;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace emok1d
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnCreate_Click(object sender, RoutedEventArgs e)
        {//СОХРАНЕНИЕ СПИСКА В ФАЙЛ
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Текстовые файлы (*.txt)|*.txt|Скрипты (*.sql)|*.sql|Документы (*.docx)|*.docx";
            if (sfd.ShowDialog() == true)
            {
                string FilePath = sfd.FileName;

                StreamWriter swriter = new StreamWriter(FilePath);

                foreach (string item in LstDataFile1.Items)
                {
                    swriter.WriteLine(item);
                }
                swriter.Close();
                MessageBox.Show($"Данные сохранены в файл {FilePath}");
            }
            else
            {
                MessageBox.Show($"Пользователь отказался от окна сохранения");
            }
        }

        private void BtnOpen_Click(object sender, RoutedEventArgs e)
        { //добавление файла
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Текстовые файлы (*.txt)|*.txt|Скрипты (*.sql)|*.sql|Документы (*.docx)|*.docx";
            if (ofd.ShowDialog() == true)
            {
                string FilePath = ofd.FileName;
                StreamReader sreader = new StreamReader(FilePath, Encoding.UTF8);

                while (!sreader.EndOfStream)//пока не конеец потока
                {
                    string line = sreader.ReadLine();
                    LstDataFile1.Items.Add(line);
                }
                sreader.Close();
            }
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        { //добавления текста
            string line = box1.Text;
            LstDataFile1.Items.Add(line);
        }

        private void BtnDel_Click(object sender, RoutedEventArgs e)
        { //удаление текста
            if (LstDataFile1.SelectedItems.Count == 0)
            {
                MessageBox.Show("Выделите текст для удаления из списка.", "Предупреждение");
            }
            else
            {
                while (LstDataFile1.SelectedItems.Count > 0)
                {
                    LstDataFile1.Items.Remove(LstDataFile1.SelectedItems[0]);
                }
            }

        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            if (LstDataFile1.SelectedItem != null)
            {
                // Изменяем текст выбранного элемента
                string userInput = userInputTextBox.Text;
                LstDataFile1.Items[LstDataFile1.SelectedIndex] = userInput;
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите элемент из списка.");
            }
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {//очищение всего
            LstDataFile1.Items.Clear();
        }

        private void BtnCountEven_Click(object sender, RoutedEventArgs e)
        {
            int evenCount = CountEvenNumbers(LstDataFile1.Items);
            MessageBox.Show($"Количество четных чисел: {evenCount}");
        }

        public int CountEvenNumbers(ItemCollection items)
        {
            if (LstDataFile1.SelectedItems.Count != 0)
            {
                int evenCount = 0;

                foreach (var selectedItem in LstDataFile1.SelectedItems)
                {
                    string str = selectedItem.ToString().Trim();
                    string[] numbers = str.Split(' ');
                    foreach (var number in numbers)
                    {
                        if (int.TryParse(number, out int num))
                        {
                            if (num % 2 == 0)
                            {
                                evenCount++;
                            }
                        }
                    }
                }
                return evenCount;
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите хотя бы один элемент.");
                return 0;
            }
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                LstDataFile1.Items.Clear();
            }
        }

        private void Window_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            Random random = new Random();
            Color randomColor = Color.FromArgb(255,
             (byte)random.Next(256),
             (byte)random.Next(256),
             (byte)random.Next(256));
            grid1.Background = new SolidColorBrush(randomColor);
        }

        private void NewWin_Click(object sender, RoutedEventArgs e)
        {
            WindowArray inputform = new WindowArray();
            inputform.ShowDialog();
        }

        private void NewWin2_Click(object sender, RoutedEventArgs e)
        {
            WindowDoubleArray inputform = new WindowDoubleArray();
            inputform.ShowDialog();
        }
    }
}