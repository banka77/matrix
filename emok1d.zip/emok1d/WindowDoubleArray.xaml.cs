﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace emok1d
{
    /// <summary>
    /// Логика взаимодействия для DoubleArray.xaml
    /// </summary>
    public partial class DoubleArray : DoubleArray
    {
        int[,] numbers = new int[4, 3];

        public DoubleArray()
        {
            InitializeComponent();

            // Заполняем массив
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    numbers[i, j] = i * j;
                }
            }

            // Обновляем DataGrid один раз после заполнения массива
            DtgDoubleArray.ItemsSource = ToDataTable(numbers).DefaultView;
        }

        private DataTable ToDataTable(int[,] array)
        {
            var table = new DataTable();
            int rows = array.GetLength(0);
            int cols = array.GetLength(1);

            // Добавляем столбцы в DataTable
            for (int i = 0; i < cols; i++)
            {
                table.Columns.Add("Column " + i); // Заголовки столбцов
            }

            // Заполняем строки
            for (int i = 0; i < rows; i++)
            {
                var row = table.NewRow();
                for (int j = 0; j < cols; j++)
                {
                    row[j] = array[i, j]; // Заполняем ячейки
                }
                table.Rows.Add(row);
            }

            return table;
        }
    }
}
